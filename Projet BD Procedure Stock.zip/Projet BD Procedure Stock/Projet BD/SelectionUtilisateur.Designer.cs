﻿namespace Projet_BD
{
    partial class SelectionUtilisateur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listAbonne = new System.Windows.Forms.ListBox();
            this.CancelButton = new System.Windows.Forms.Button();
            this.okButton = new System.Windows.Forms.Button();
            this.AddButton = new System.Windows.Forms.Button();
            this.infoList = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listAbonne
            // 
            this.listAbonne.FormattingEnabled = true;
            this.listAbonne.HorizontalScrollbar = true;
            this.listAbonne.Location = new System.Drawing.Point(12, 38);
            this.listAbonne.Name = "listAbonne";
            this.listAbonne.Size = new System.Drawing.Size(268, 277);
            this.listAbonne.TabIndex = 0;
            this.listAbonne.SelectedIndexChanged += new System.EventHandler(this.listAbonne_SelectedIndexChanged);
            this.listAbonne.KeyDown += new System.Windows.Forms.KeyEventHandler(this.listAbonne_KeyDown);
            this.listAbonne.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.listAbonne_MouseDoubleClick);
            // 
            // CancelButton
            // 
            this.CancelButton.Location = new System.Drawing.Point(40, 367);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(75, 23);
            this.CancelButton.TabIndex = 1;
            this.CancelButton.Text = "Quitter";
            this.CancelButton.UseVisualStyleBackColor = true;
            this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click_1);
            // 
            // okButton
            // 
            this.okButton.Location = new System.Drawing.Point(177, 367);
            this.okButton.Name = "okButton";
            this.okButton.Size = new System.Drawing.Size(75, 23);
            this.okButton.TabIndex = 2;
            this.okButton.Text = "Connexion";
            this.okButton.UseVisualStyleBackColor = true;
            this.okButton.Click += new System.EventHandler(this.okButton_Click_1);
            // 
            // AddButton
            // 
            this.AddButton.Location = new System.Drawing.Point(75, 326);
            this.AddButton.Name = "AddButton";
            this.AddButton.Size = new System.Drawing.Size(142, 23);
            this.AddButton.TabIndex = 3;
            this.AddButton.Text = "Ajouter un Abonné";
            this.AddButton.UseVisualStyleBackColor = true;
            this.AddButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // infoList
            // 
            this.infoList.AutoSize = true;
            this.infoList.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.infoList.Location = new System.Drawing.Point(71, 12);
            this.infoList.Name = "infoList";
            this.infoList.Size = new System.Drawing.Size(156, 20);
            this.infoList.TabIndex = 4;
            this.infoList.Text = "Choix de l\'utilisateur :";
            // 
            // SelectionUtilisateur
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 405);
            this.Controls.Add(this.infoList);
            this.Controls.Add(this.AddButton);
            this.Controls.Add(this.okButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.listAbonne);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "SelectionUtilisateur";
            this.Text = "SelectionUtilisateur";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listAbonne;
        private System.Windows.Forms.Button CancelButton;
        private System.Windows.Forms.Button okButton;
        private System.Windows.Forms.Button AddButton;
        private System.Windows.Forms.Label infoList;
    }
}