﻿namespace Projet_BD
{
    partial class InterfaceClient
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.listeCompositeur = new System.Windows.Forms.ListBox();
            this.listeOeuvre = new System.Windows.Forms.ListBox();
            this.listeAlbum = new System.Windows.Forms.ListBox();
            this.StatutEmprunt = new System.Windows.Forms.Label();
            this.nomCompositeur = new System.Windows.Forms.Label();
            this.nameOeuvres = new System.Windows.Forms.Label();
            this.nameAlbum = new System.Windows.Forms.Label();
            this.EmpruntButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.QuitButton = new System.Windows.Forms.Button();
            this.listeEmprunt = new System.Windows.Forms.ListBox();
            this.userName = new System.Windows.Forms.Label();
            this.picturePreview = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picturePreview)).BeginInit();
            this.SuspendLayout();
            // 
            // listeCompositeur
            // 
            this.listeCompositeur.FormattingEnabled = true;
            this.listeCompositeur.Location = new System.Drawing.Point(5, 25);
            this.listeCompositeur.Name = "listeCompositeur";
            this.listeCompositeur.Size = new System.Drawing.Size(196, 589);
            this.listeCompositeur.TabIndex = 0;
            this.listeCompositeur.SelectedIndexChanged += new System.EventHandler(this.listeCompositeur_SelectedIndexChanged_1);
            // 
            // listeOeuvre
            // 
            this.listeOeuvre.FormattingEnabled = true;
            this.listeOeuvre.HorizontalScrollbar = true;
            this.listeOeuvre.Location = new System.Drawing.Point(216, 25);
            this.listeOeuvre.Name = "listeOeuvre";
            this.listeOeuvre.Size = new System.Drawing.Size(326, 589);
            this.listeOeuvre.TabIndex = 1;
            this.listeOeuvre.SelectedIndexChanged += new System.EventHandler(this.listeOeuvre_SelectedIndexChanged_1);
            // 
            // listeAlbum
            // 
            this.listeAlbum.FormattingEnabled = true;
            this.listeAlbum.HorizontalScrollbar = true;
            this.listeAlbum.Location = new System.Drawing.Point(560, 25);
            this.listeAlbum.Name = "listeAlbum";
            this.listeAlbum.Size = new System.Drawing.Size(307, 264);
            this.listeAlbum.TabIndex = 2;
            this.listeAlbum.SelectedIndexChanged += new System.EventHandler(this.listeAlbum_SelectedIndexChanged);
            // 
            // StatutEmprunt
            // 
            this.StatutEmprunt.AutoSize = true;
            this.StatutEmprunt.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StatutEmprunt.Location = new System.Drawing.Point(884, 25);
            this.StatutEmprunt.Name = "StatutEmprunt";
            this.StatutEmprunt.Size = new System.Drawing.Size(72, 29);
            this.StatutEmprunt.TabIndex = 3;
            this.StatutEmprunt.Text = "Etat : ";
            // 
            // nomCompositeur
            // 
            this.nomCompositeur.AutoSize = true;
            this.nomCompositeur.Location = new System.Drawing.Point(25, 9);
            this.nomCompositeur.Name = "nomCompositeur";
            this.nomCompositeur.Size = new System.Drawing.Size(114, 13);
            this.nomCompositeur.TabIndex = 4;
            this.nomCompositeur.Text = "Liste des compositeurs";
            // 
            // nameOeuvres
            // 
            this.nameOeuvres.AutoSize = true;
            this.nameOeuvres.Location = new System.Drawing.Point(319, 9);
            this.nameOeuvres.Name = "nameOeuvres";
            this.nameOeuvres.Size = new System.Drawing.Size(92, 13);
            this.nameOeuvres.TabIndex = 5;
            this.nameOeuvres.Text = "Liste des Oeuvres";
            // 
            // nameAlbum
            // 
            this.nameAlbum.AutoSize = true;
            this.nameAlbum.Location = new System.Drawing.Point(665, 9);
            this.nameAlbum.Name = "nameAlbum";
            this.nameAlbum.Size = new System.Drawing.Size(86, 13);
            this.nameAlbum.TabIndex = 6;
            this.nameAlbum.Text = "Liste des Albums";
            // 
            // EmpruntButton
            // 
            this.EmpruntButton.Location = new System.Drawing.Point(619, 548);
            this.EmpruntButton.Name = "EmpruntButton";
            this.EmpruntButton.Size = new System.Drawing.Size(189, 69);
            this.EmpruntButton.TabIndex = 7;
            this.EmpruntButton.Text = "Emprunter";
            this.EmpruntButton.UseVisualStyleBackColor = true;
            this.EmpruntButton.Click += new System.EventHandler(this.EmpruntButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Enabled = false;
            this.BackButton.Location = new System.Drawing.Point(941, 463);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(251, 33);
            this.BackButton.TabIndex = 8;
            this.BackButton.Text = "Retourner";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // QuitButton
            // 
            this.QuitButton.Location = new System.Drawing.Point(966, 537);
            this.QuitButton.Name = "QuitButton";
            this.QuitButton.Size = new System.Drawing.Size(202, 76);
            this.QuitButton.TabIndex = 9;
            this.QuitButton.Text = "Deconnexion";
            this.QuitButton.UseVisualStyleBackColor = true;
            this.QuitButton.Click += new System.EventHandler(this.QuitButton_Click);
            // 
            // listeEmprunt
            // 
            this.listeEmprunt.FormattingEnabled = true;
            this.listeEmprunt.HorizontalScrollbar = true;
            this.listeEmprunt.Location = new System.Drawing.Point(887, 124);
            this.listeEmprunt.Name = "listeEmprunt";
            this.listeEmprunt.Size = new System.Drawing.Size(351, 329);
            this.listeEmprunt.TabIndex = 10;
            this.listeEmprunt.SelectedIndexChanged += new System.EventHandler(this.listeEmprunt_SelectedIndexChanged);
            // 
            // userName
            // 
            this.userName.AutoSize = true;
            this.userName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userName.Location = new System.Drawing.Point(883, 96);
            this.userName.Name = "userName";
            this.userName.Size = new System.Drawing.Size(80, 18);
            this.userName.TabIndex = 11;
            this.userName.Text = "UserName";
            // 
            // picturePreview
            // 
            this.picturePreview.Location = new System.Drawing.Point(560, 295);
            this.picturePreview.Name = "picturePreview";
            this.picturePreview.Size = new System.Drawing.Size(307, 247);
            this.picturePreview.TabIndex = 13;
            this.picturePreview.TabStop = false;
            // 
            // InterfaceClient
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1250, 629);
            this.Controls.Add(this.picturePreview);
            this.Controls.Add(this.userName);
            this.Controls.Add(this.listeEmprunt);
            this.Controls.Add(this.QuitButton);
            this.Controls.Add(this.BackButton);
            this.Controls.Add(this.EmpruntButton);
            this.Controls.Add(this.nameAlbum);
            this.Controls.Add(this.nameOeuvres);
            this.Controls.Add(this.nomCompositeur);
            this.Controls.Add(this.StatutEmprunt);
            this.Controls.Add(this.listeAlbum);
            this.Controls.Add(this.listeOeuvre);
            this.Controls.Add(this.listeCompositeur);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "InterfaceClient";
            this.Text = "InterfaceClient";
            ((System.ComponentModel.ISupportInitialize)(this.picturePreview)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listeCompositeur;
        private System.Windows.Forms.ListBox listeOeuvre;
        private System.Windows.Forms.ListBox listeAlbum;
        private System.Windows.Forms.Label StatutEmprunt;
        private System.Windows.Forms.Label nomCompositeur;
        private System.Windows.Forms.Label nameOeuvres;
        private System.Windows.Forms.Label nameAlbum;
        private System.Windows.Forms.Button EmpruntButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button QuitButton;
        private System.Windows.Forms.ListBox listeEmprunt;
        private System.Windows.Forms.Label userName;
        private System.Windows.Forms.PictureBox picturePreview;
    }
}

