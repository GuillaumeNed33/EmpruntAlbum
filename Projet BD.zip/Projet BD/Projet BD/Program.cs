﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projet_BD
{
    static class Program
    {
        /// <summary>
        /// Point d'entrée principal de l'application.
        /// </summary>
        [STAThread]

        static void Main()
        {
            Abonne AboSelection = null;
            bool openWindow = true;

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            while (openWindow) //Tant que le programme tourne
            {
                //Toute les fenetre sont redirigés vers la sélection d'abonné à leurs fermeture
                SelectionUtilisateur select = new SelectionUtilisateur();
                Application.Run(select); //Le menu de selection d'abonné est en route
                AboSelection = select.selection;

                if (select.NextStep) //Si dans la fenetre precedente, L'utilisateur decide de se connecter
                {
                    Connexion connect = new Connexion(AboSelection);
                    Application.Run(connect); //Lancement fenetre de connexion

                    if(connect.valide) //Si la connexion est réussie
                        Application.Run(new InterfaceClient(AboSelection)); //On lance l'interface d'emprunt
                }

                else if(select.AddAbonne) //Si l'utilisateur clic sur "Ajouté un abonné"
                {
                    Application.Run(new AddUsers()); //On lance le formulaire d'ajout d'abonné
                }

                else
                    openWindow = false; //La fenetre se ferme si on clic sur fermer
            }
        }
    }
}
