﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projet_BD
{
    public partial class SelectionUtilisateur : Form
    {
        public bool NextStep { get; set; }
        public bool AddAbonne { get; set; }

        private OleDbConnection dbConnection { get; set; }
        List<Abonne> abonnes = new List<Abonne>();
        
        public Abonne selection = null;

        public SelectionUtilisateur()
        {
            InitializeComponent();
            NextStep = false;
            AddAbonne = false;
            connexion();
            getAbonne();

            //Si la liste n'est pas vide, le premier de la liste est automatiquement sélectionné
            if (listAbonne.Items.Count != 0 && selection == null)
            {
                listAbonne.SelectedItem = listAbonne.Items[0];
                selection = (Abonne)(listAbonne.Items[0]);
            }

        }

        //Connexion à la base
        private void connexion()
        {
            #region Phase de connection
            string nomBase = "Musique";
            string ChaineBd = "Provider=SQLOLEDB; Data Source=INFO-SIMPLET;" +
            "Initial Catalog=" + nomBase + ";Uid=ETD; Pwd=ETD;";
            dbConnection = new OleDbConnection(ChaineBd);
            dbConnection.Open();
            #endregion
        }

        //Recuperation de la liste des Abonnés
        public void getAbonne()
        {
            #region Accès et lecture de la base
            string sql = "Select Code_Abonné, Nom_Abonné, Prénom_Abonné FROM Abonné "
               + "ORDER BY Nom_Abonné ";
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            #endregion

            #region Insertion des Abonnés dans la liste
            while (reader.Read())
            {
                if(reader.GetValue(1).ToString().Count() > 0)
                {
                    Abonne m = new Abonne(reader.GetValue(0).ToString(), reader.GetValue(1).ToString(), reader.GetValue(2).ToString());
                    abonnes.Add(m);
                }                
            }
            reader.Close();
            #endregion

            #region Insertion des abonnés dans la listbox
            foreach (Abonne abo in abonnes)
            {
                listAbonne.Items.Add(abo);
            }
            #endregion
        }

        //Ferme la fenetre courante
        private void CancelButton_Click_1(object sender, EventArgs e)
        {
            Close();
        }

        //Valide la selection
        private void okButton_Click_1(object sender, EventArgs e)
        {
                NextStep = true;
                Close();
        }

        //Recuperation de l'abonné selectionné
        private void listAbonne_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listAbonne.SelectedItems != null)
            {
                selection = (Abonne)(listAbonne.SelectedItem);
            }
        }

        //Passage à la phase d'ajout de l'abonné (Dans Program.cs)
        private void AddButton_Click(object sender, EventArgs e)
        {
            AddAbonne = true;
            Close();
        }

        //Un double clic permet de se connecter avec l'abonné selectionné
        private void listAbonne_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            okButton_Click_1(sender, e);
        }

        //La touche "Entrée" permet de se connecter avec l'abonné selectionné
        private void listAbonne_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                okButton_Click_1(sender, e);
            }
        }
    }
}
