﻿namespace Projet_BD
{
    partial class AddUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.name = new System.Windows.Forms.Label();
            this.surname = new System.Windows.Forms.Label();
            this.log = new System.Windows.Forms.Label();
            this.pass = new System.Windows.Forms.Label();
            this.confPass = new System.Windows.Forms.Label();
            this.ConfirmButton = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.textName = new System.Windows.Forms.TextBox();
            this.textFirstName = new System.Windows.Forms.TextBox();
            this.textLogin = new System.Windows.Forms.TextBox();
            this.textPass = new System.Windows.Forms.TextBox();
            this.textPassConfirm = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.Location = new System.Drawing.Point(100, 27);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(49, 18);
            this.name.TabIndex = 0;
            this.name.Text = "Nom :";
            // 
            // surname
            // 
            this.surname.AutoSize = true;
            this.surname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surname.Location = new System.Drawing.Point(83, 61);
            this.surname.Name = "surname";
            this.surname.Size = new System.Drawing.Size(69, 18);
            this.surname.TabIndex = 5;
            this.surname.Text = "Prénom :";
            // 
            // log
            // 
            this.log.AutoSize = true;
            this.log.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.log.Location = new System.Drawing.Point(100, 100);
            this.log.Name = "log";
            this.log.Size = new System.Drawing.Size(52, 18);
            this.log.TabIndex = 6;
            this.log.Text = "Login :";
            // 
            // pass
            // 
            this.pass.AutoSize = true;
            this.pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pass.Location = new System.Drawing.Point(69, 140);
            this.pass.Name = "pass";
            this.pass.Size = new System.Drawing.Size(83, 18);
            this.pass.TabIndex = 7;
            this.pass.Text = "Password :";
            // 
            // confPass
            // 
            this.confPass.AutoSize = true;
            this.confPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confPass.Location = new System.Drawing.Point(12, 178);
            this.confPass.Name = "confPass";
            this.confPass.Size = new System.Drawing.Size(140, 18);
            this.confPass.TabIndex = 8;
            this.confPass.Text = "Confirm Password :";
            // 
            // ConfirmButton
            // 
            this.ConfirmButton.Location = new System.Drawing.Point(395, 226);
            this.ConfirmButton.Name = "ConfirmButton";
            this.ConfirmButton.Size = new System.Drawing.Size(75, 23);
            this.ConfirmButton.TabIndex = 9;
            this.ConfirmButton.Text = "Soumettre";
            this.ConfirmButton.UseVisualStyleBackColor = true;
            this.ConfirmButton.Click += new System.EventHandler(this.Confirm_ButtonClick);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(155, 226);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(75, 23);
            this.Cancel.TabIndex = 10;
            this.Cancel.Text = "Annuler";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click1);
            // 
            // textName
            // 
            this.textName.Location = new System.Drawing.Point(155, 28);
            this.textName.Name = "textName";
            this.textName.Size = new System.Drawing.Size(315, 20);
            this.textName.TabIndex = 11;
            this.textName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textName_KeyDown);
            // 
            // textFirstName
            // 
            this.textFirstName.Location = new System.Drawing.Point(155, 62);
            this.textFirstName.Name = "textFirstName";
            this.textFirstName.Size = new System.Drawing.Size(315, 20);
            this.textFirstName.TabIndex = 12;
            this.textFirstName.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textFirstName_KeyDown);
            // 
            // textLogin
            // 
            this.textLogin.Location = new System.Drawing.Point(155, 101);
            this.textLogin.Name = "textLogin";
            this.textLogin.Size = new System.Drawing.Size(315, 20);
            this.textLogin.TabIndex = 13;
            this.textLogin.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textLogin_KeyDown);
            // 
            // textPass
            // 
            this.textPass.Location = new System.Drawing.Point(155, 140);
            this.textPass.Name = "textPass";
            this.textPass.PasswordChar = '*';
            this.textPass.Size = new System.Drawing.Size(315, 20);
            this.textPass.TabIndex = 14;
            this.textPass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textPass_KeyDown);
            // 
            // textPassConfirm
            // 
            this.textPassConfirm.Location = new System.Drawing.Point(155, 178);
            this.textPassConfirm.Name = "textPassConfirm";
            this.textPassConfirm.PasswordChar = '*';
            this.textPassConfirm.Size = new System.Drawing.Size(315, 20);
            this.textPassConfirm.TabIndex = 15;
            this.textPassConfirm.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textPassConfirm_KeyDown);
            // 
            // AddUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(578, 261);
            this.Controls.Add(this.textPassConfirm);
            this.Controls.Add(this.textPass);
            this.Controls.Add(this.textLogin);
            this.Controls.Add(this.textFirstName);
            this.Controls.Add(this.textName);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.ConfirmButton);
            this.Controls.Add(this.confPass);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.log);
            this.Controls.Add(this.surname);
            this.Controls.Add(this.name);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "AddUsers";
            this.Text = "AddUsers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label name;
        private System.Windows.Forms.Label surname;
        private System.Windows.Forms.Label log;
        private System.Windows.Forms.Label pass;
        private System.Windows.Forms.Label confPass;
        private System.Windows.Forms.Button ConfirmButton;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.TextBox textName;
        private System.Windows.Forms.TextBox textPassConfirm;
        private System.Windows.Forms.TextBox textLogin;
        private System.Windows.Forms.TextBox textPass;
        private System.Windows.Forms.TextBox textFirstName;
    }
}