﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_BD
{
    class Album
    {
        string code_Album;
        string titre_Album;

        public Album(string code, string titre)
        {
            code_Album = code;
            titre_Album = titre;
        }
        public string Code_Album
        {
            get { return code_Album; }
            set { code_Album = value; }
        }
        public string Titre_Album
        {
            get { return titre_Album; }
            set { titre_Album = value; }
        }

        public override string ToString()
        {
            return Titre_Album;
        }
    }
}
