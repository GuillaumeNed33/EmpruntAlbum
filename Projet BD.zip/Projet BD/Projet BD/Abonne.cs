﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_BD
{
    public class Abonne
    {
        string code_Abonne;
        string nom_Abonne;
        string prénom_Abonne;

        public Abonne(string code, string nom, string prenom)
        {
            code_Abonne = code;
            nom_Abonne = nom;
            prénom_Abonne = prenom;
        }
        public string Code_Abonne
        {
            get { return code_Abonne; }
            set { code_Abonne = value; }
        }
        public string Nom_Abonne
        {
            get { return nom_Abonne; }
            set { nom_Abonne = value; }
        }
        public string Prénom_Abonne
        {
            get { return prénom_Abonne; }
            set { prénom_Abonne = value; }
        }
        public override string ToString()
        {
            return Nom_Abonne + ", " + Prénom_Abonne;
        } 
    }
}
