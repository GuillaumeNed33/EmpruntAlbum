﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projet_BD
{
    public partial class Connexion : Form
    {
        public bool valide = false;
        private Abonne User = null;
        private OleDbConnection dbConnection { get; set; }
             

        public Connexion(Abonne SelectAbonne)
        {
            InitializeComponent();
            User = SelectAbonne; //On rend accessible l'abonné selectionné dans toute cette interface
            connexion();
        }

        //Connexion à la base de données
        private void connexion()
        {
            #region Phase de connection
            string nomBase = "Musique";
            string ChaineBd = "Provider=SQLOLEDB; Data Source=INFO-SIMPLET;" +
            "Initial Catalog=" + nomBase + ";Uid=ETD; Pwd=ETD;";
            dbConnection = new OleDbConnection(ChaineBd);
            dbConnection.Open();
            #endregion
        }

        //Etablie la connexion de l'abonné et les verifications nécéssaires
        private void ConnectButton_Click(object sender, EventArgs e)
        {
            #region 
            string sql = "Select Login, Password FROM Abonné "
               + "WHERE Abonné.Code_Abonné = '" + User.Code_Abonne +"'";
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            string login ="";
            string password ="";

            while (reader.Read())
            {
                login = (reader.GetValue(0).ToString());
                password = (reader.GetValue(1).ToString());
            }
            reader.Close();
            #endregion

            if (textlog.Text == login && textPass.Text == password) //Verification login + mot de passe
            {
                valide = true;
                Close();
            }
            else
            {
                MessageBox.Show("le login ou le mot de passe est incorrect.");
            }
        }

        //Ferme la fenetre courante
        private void Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        //L'ensemble des fonctions suivantes permet de valider en appuyant sur "Entrée" à tout moment
        private void textlog_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                ConnectButton_Click(sender, e);
            }
        }

        private void textPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                ConnectButton_Click(sender, e);
            }
        }
    }
}
