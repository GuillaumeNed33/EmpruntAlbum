﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projet_BD
{
    class Oeuvre
    {
        string code_Oeuvre;
        string titre_Oeuvre;
        
        public Oeuvre(string code, string titre)
        {
            code_Oeuvre = code;
            titre_Oeuvre = titre;
        }
        public string Code_Oeuvre
        {
            get { return code_Oeuvre; }
            set { code_Oeuvre = value; }
        }
        public string Titre_Oeuvre
        {
            get { return titre_Oeuvre; }
            set { titre_Oeuvre = value; }
        }

        public override string ToString()
        {
            return Titre_Oeuvre;
        }
    }
}
