﻿namespace Projet_BD
{
    partial class Connexion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Id = new System.Windows.Forms.Label();
            this.Pass = new System.Windows.Forms.Label();
            this.textlog = new System.Windows.Forms.TextBox();
            this.textPass = new System.Windows.Forms.TextBox();
            this.ConnectButton = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Id
            // 
            this.Id.AutoSize = true;
            this.Id.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Id.Location = new System.Drawing.Point(59, 20);
            this.Id.Name = "Id";
            this.Id.Size = new System.Drawing.Size(73, 29);
            this.Id.TabIndex = 2;
            this.Id.Text = "Login";
            // 
            // Pass
            // 
            this.Pass.AutoSize = true;
            this.Pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pass.Location = new System.Drawing.Point(12, 66);
            this.Pass.Name = "Pass";
            this.Pass.Size = new System.Drawing.Size(120, 29);
            this.Pass.TabIndex = 3;
            this.Pass.Text = "Password";
            // 
            // textlog
            // 
            this.textlog.Location = new System.Drawing.Point(138, 24);
            this.textlog.MaximumSize = new System.Drawing.Size(300, 25);
            this.textlog.MinimumSize = new System.Drawing.Size(300, 25);
            this.textlog.Name = "textlog";
            this.textlog.Size = new System.Drawing.Size(300, 20);
            this.textlog.TabIndex = 4;
            this.textlog.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textlog_KeyDown);
            // 
            // textPass
            // 
            this.textPass.Location = new System.Drawing.Point(138, 71);
            this.textPass.MaximumSize = new System.Drawing.Size(300, 25);
            this.textPass.MinimumSize = new System.Drawing.Size(300, 25);
            this.textPass.Name = "textPass";
            this.textPass.PasswordChar = '*';
            this.textPass.Size = new System.Drawing.Size(300, 20);
            this.textPass.TabIndex = 5;
            this.textPass.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textPass_KeyDown);
            // 
            // ConnectButton
            // 
            this.ConnectButton.Location = new System.Drawing.Point(337, 121);
            this.ConnectButton.Name = "ConnectButton";
            this.ConnectButton.Size = new System.Drawing.Size(101, 35);
            this.ConnectButton.TabIndex = 6;
            this.ConnectButton.Text = "Valider";
            this.ConnectButton.UseVisualStyleBackColor = true;
            this.ConnectButton.Click += new System.EventHandler(this.ConnectButton_Click);
            // 
            // Cancel
            // 
            this.Cancel.Location = new System.Drawing.Point(64, 121);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(101, 35);
            this.Cancel.TabIndex = 7;
            this.Cancel.Text = "Annuler";
            this.Cancel.UseVisualStyleBackColor = true;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Connexion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(487, 168);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.ConnectButton);
            this.Controls.Add(this.textPass);
            this.Controls.Add(this.textlog);
            this.Controls.Add(this.Pass);
            this.Controls.Add(this.Id);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Connexion";
            this.Text = "Connexion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Id;
        private System.Windows.Forms.Label Pass;
        private System.Windows.Forms.TextBox textlog;
        private System.Windows.Forms.TextBox textPass;
        private System.Windows.Forms.Button ConnectButton;
        private System.Windows.Forms.Button Cancel;
    }
}