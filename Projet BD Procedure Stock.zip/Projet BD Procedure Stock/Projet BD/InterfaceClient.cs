﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;

namespace Projet_BD
{
    public partial class InterfaceClient : Form
    {
        public string name = "";

        private OleDbConnection dbConnection { get; set; }
        List<Musicien> musiciens;
        List<Oeuvre> oeuvres;
        List<Album> albums;
        List<Album> emprunts;

        Musicien selectionMusicien = null;
        Abonne Utilisateur = null;
        Oeuvre OeuvreSelection = null;
        Album AlbumSelection = null;
        Album EmpruntSelection = null;

        byte[] buffer = new byte[2048 * 2048];
        int cptPochette = 0;

        bool trouve = false;
        string etatEmprunt = null;

        public InterfaceClient(Abonne Aboselection)
        {
            InitializeComponent();
            Utilisateur = Aboselection;
            userName.Text = "Liste des emprunts de : " + Utilisateur.ToString();
            connexion();

            getEmpruntAbonne(Utilisateur);
            getMusiciens();
            listeCompositeur.SelectedItem = listeCompositeur.Items[0];
            selectionMusicien = (Musicien)(listeCompositeur.SelectedItem);
        }

        //Connexion à la base
        private void connexion()
        {
            #region Phase de connection
            string nomBase = "Musique";
            string ChaineBd = "Provider=SQLOLEDB; Data Source=INFO-SIMPLET;" +
            "Initial Catalog=" + nomBase + ";Uid=ETD; Pwd=ETD;";
            dbConnection = new OleDbConnection(ChaineBd);
            dbConnection.Open();
            #endregion
        }

        //Affiche la liste des emprunts qu'a effectué l'abonné connecté
        private void getEmpruntAbonne(Abonne abo)
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE getEmpruntAbonne_NM_GN " + abo.Code_Abonne;

            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            #endregion

            #region Insertion des albums empruntés dans la liste
            emprunts = new List<Album>();
            while (reader.Read())
            {
                Album a = new Album(reader.GetValue(0).ToString(), reader.GetValue(1).ToString());
                emprunts.Add(a);
            }
            reader.Close();
            #endregion

            #region Insertion des albums empruntés dans la listbox
            foreach (Album a in emprunts)
            {
                listeEmprunt.Items.Add(a);
            }
            #endregion
        }

        //Affiche la liste des Compositeurs de la base
        private void getMusiciens()
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE getMusiciens_NM_GN ";
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            #endregion

            #region Insertion des musiciens dans la liste
            musiciens = new List<Musicien>();
            while (reader.Read())
            {
                Musicien m = new Musicien(reader.GetValue(0).ToString(), reader.GetValue(1).ToString(), reader.GetValue(2).ToString());
                musiciens.Add(m);
            }
            reader.Close();
            #endregion

            #region Insertion des musiciens dans la listbox
            foreach (Musicien mus in musiciens)
            {
                listeCompositeur.Items.Add(mus);
            }
            #endregion
        }

        //Actualise les affichages au changement de musicien sélectionné
        private void listeCompositeur_SelectedIndexChanged_1(object sender, EventArgs e)
        {            
            if (listeCompositeur.SelectedItem != null)
            {
                Musicien list_mus = (Musicien)(listeCompositeur.SelectedItem);

                foreach (Musicien m in musiciens)
                {
                    if (list_mus.Code_Musicien == m.Code_Musicien)
                    {
                        selectionMusicien = m;
                    }
                }

                getOeuvres(selectionMusicien);
                listeOeuvre.SelectedItem = listeOeuvre.Items[0];
                OeuvreSelection = (Oeuvre)(listeOeuvre.SelectedItem);
            }
        }

        //Affiche la liste des oeuvres composé par le musiciens séléectionné
        private void getOeuvres(Musicien m)
        {
            if (m != null)
            {
                listeOeuvre.Items.Clear();
                listeAlbum.Items.Clear();
                StatutEmprunt.Text = "Etat : ";

                #region Accès et lecture de la base
                string sql = "EXECUTE getOeuvres_NM_GN " + m.Code_Musicien;

                OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
                OleDbDataReader reader = cmd.ExecuteReader();
                #endregion

                #region Insertion des oeuvres dans la liste
                oeuvres = new List<Oeuvre>();
                while (reader.Read())
                {
                    Oeuvre oeuv = new Oeuvre(reader.GetValue(0).ToString(), reader.GetValue(1).ToString());
                    oeuvres.Add(oeuv);
                }
                reader.Close();
                #endregion

                #region Insertion des oeuvres dans la listbox
                foreach (Oeuvre o in oeuvres)
                    listeOeuvre.Items.Add(o);
                #endregion
            }
        }

        //Actualise les albums en fonctions de l'oeuvre sélectionnée
        private void listeOeuvre_SelectedIndexChanged_1(object sender, EventArgs e)
        {         
            if (listeOeuvre.SelectedItem != null)
            {
                Oeuvre list_alb = (Oeuvre)(listeOeuvre.SelectedItem);

                foreach (Oeuvre o in oeuvres)
                {
                    if (list_alb == o)
                    {
                        OeuvreSelection = o;
                    }
                }

                getAlbums(OeuvreSelection, selectionMusicien);  
                listeAlbum.SelectedItem = listeAlbum.Items[0];
                AlbumSelection = (Album)(listeAlbum.SelectedItem);
            }
        }

        //Affiche la liste des albums contenant l'oeuvre sélectionée
        private void getAlbums(Oeuvre select, Musicien m)
        {
            listeAlbum.Items.Clear();
            StatutEmprunt.Text = "Etat : ";

            if (select != null && m != null)
            {
                #region Accès et lecture de la base
                string sql = "EXECUTE getAlbums_NM_GN " + select.Code_Oeuvre + ", " + m.Code_Musicien;

                OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
                OleDbDataReader reader = cmd.ExecuteReader();
                #endregion

                #region Insertion des albums dans la liste
                albums = new List<Album>();
                while (reader.Read())
                {
                    Album alb = new Album(reader.GetValue(0).ToString(), reader.GetValue(1).ToString());
                    albums.Add(alb);
                }
                reader.Close();
                #endregion

                #region Insertion des albums dans la listbox
                foreach (Album alb in albums)
                    listeAlbum.Items.Add(alb);
                #endregion
            }
        }

        //Actualise le label de disponibilité et l'image de la pochette au changement de sélection de l'album
        private void listeAlbum_SelectedIndexChanged(object sender, EventArgs e)
        {
            StatutEmprunt.Text = "Etat : ";
            trouve = false;

            if (listeAlbum.SelectedItem != null)
            {
                Album alb = (Album)(listeAlbum.SelectedItem);

                foreach (Album a in albums)
                {
                    if (alb == a)
                    {
                        AlbumSelection = a;
                    }
                }
                afficherPochette(AlbumSelection);
                getEmprunt(AlbumSelection);
            }
        }

        //Verifie si l'album est emprunté ou non et actualise le label
        private void getEmprunt(Album album)
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE getEmprunt_NM_GN " + album.Code_Album;

            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            string statut = null;
            trouve = false;
            #endregion

            #region Verification du statut de l'album
            while (reader.Read() && !trouve)
            {
                name = reader.GetValue(0).ToString();
                if (reader.GetValue(0).ToString() != "" && reader.GetValue(1).ToString() == "")
                {
                    statut = "Emprunté";
                    trouve = true;
                }

                else if (reader.GetValue(0).ToString() != "" && reader.GetValue(1).ToString() != "")
                {
                    statut = "Disponible";
                    trouve = true;
                }

                else if (reader.GetValue(0).ToString() == "" && reader.GetValue(1).ToString() != "")
                {
                    statut = "Disponible";
                    trouve = true;
                }

                else if (reader.GetValue(0).ToString() == "" && reader.GetValue(1).ToString() == "")
                {
                    statut = "Disponible";
                    trouve = true;
                }
            }
            reader.Close();

            if(!trouve)
                statut = "Disponible";
            #endregion

            #region  Mis a jour du statut
            StatutEmprunt.Text = "Etat : " + statut;
            #endregion

        }

        //Ferme la fenetre courante
        private void QuitButton_Click(object sender, EventArgs e)
        {
            dbConnection.Close();
            Close();
        }

        //Permet de rendre l'album emprunté selectionné 
        private void BackButton_Click(object sender, EventArgs e)
        {
            retourAlbum(Utilisateur, EmpruntSelection);
            getEmprunt((Album)(listeEmprunt.SelectedItem));
            listeEmprunt.Items.Clear();
            getEmpruntAbonne(Utilisateur);

            if(listeEmprunt.SelectedItem == null)
            {
                BackButton.Enabled = false;
            }

            MessageBox.Show("Album de nouveau disponible.");
        }

        //Effectue le retour dans la base de données
        private void retourAlbum(Abonne abo, Album alb)
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE retourAlbum_NM_GN " + alb.Code_Album + ", " + abo.Code_Abonne;

            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            reader.Read();
            reader.Close();
            #endregion
        }

        //Mets  à jour l'album sélectionné dans la liste des emprunts
        private void listeEmprunt_SelectedIndexChanged(object sender, EventArgs e)
        {
            BackButton.Enabled = true;
           
            EmpruntSelection = (Album)(listeEmprunt.SelectedItem);
            if (EmpruntSelection == null)
                BackButton.Enabled = false;
        }

        //Effectue un emprunt si cela est possible
        private void EmpruntButton_Click(object sender, EventArgs e)
        {
            if (StatutEmprunt.Text == "Etat : Disponible")
            {
                verifEmprunt(Utilisateur, AlbumSelection);
                empruntAlbum(Utilisateur, AlbumSelection, etatEmprunt);
                listeEmprunt.Items.Clear();
                getEmpruntAbonne(Utilisateur);
                MessageBox.Show("Album ajouté à votre collection.");
            }
            else
                MessageBox.Show("Album indisponible pour le moment.");
            getEmprunt(AlbumSelection);
        }

        //Verifie que l'album est deja dans la base de données (au niveau de l'emprunt)
        private void verifEmprunt(Abonne abo, Album alb)
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE verifEmprunt_NM_GN " + alb.Code_Album;

            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();

            etatEmprunt = "OutDataBase";

            while (reader.Read())
            {
               etatEmprunt = "InDataBase";
            }

            reader.Close();
            #endregion
        }

        //Emprunte l'album selectionné
        private void empruntAlbum(Abonne abo, Album alb, string etat)
        {
            #region Accès et lecture de la base
            string sql = null;

            if (etatEmprunt == "InDataBase")
            {
                sql = "EXECUTE empruntAlbumIn_NM_GN " + abo.Code_Abonne + " ," + alb.Code_Album;
            }

            else if (etatEmprunt == "OutDataBase")
            {
                sql = "EXECUTE empruntAlbumOut_NM_GN " + abo.Code_Abonne + " ," + alb.Code_Album;
            }

            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            reader.Read();
            reader.Close();
            #endregion
        }

        //Affichage de la pochette de l'album sélectionné
        private void afficherPochette(Album alb)
        {
            #region Accès et lecture de la base
            string sql = "EXECUTE pochetteAlbum_NM_GN " + alb.Code_Album;


            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                reader.GetBytes(0, 0, buffer, 0, 99999);
            }
            reader.Close();

            #endregion

            MemoryStream stream = new MemoryStream(buffer);
            Image.FromStream(stream).Save("pochette" + cptPochette.ToString() + "jpg");
            Image img = Image.FromFile("pochette" + (cptPochette++).ToString() + "jpg");


            if ((img.Height > picturePreview.Height) || (img.Width > picturePreview.Width))
            {
                picturePreview.SizeMode = PictureBoxSizeMode.StretchImage;
            }
            else
            {
                picturePreview.SizeMode = PictureBoxSizeMode.CenterImage;

            }

            picturePreview.Image = img;
            stream.Close();
        }
    }
}