﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Projet_BD
{
    public partial class AddUsers : Form
    {
        private OleDbConnection dbConnection { get; set; }

        public AddUsers()
        {
            InitializeComponent();
        }

        // se connecte à la base de données Musique
        private void connexion()
        {
            #region Phase de connection
            string nomBase = "Musique";
            string ChaineBd = "Provider=SQLOLEDB; Data Source=INFO-SIMPLET;" +
            "Initial Catalog=" + nomBase + ";Uid=ETD; Pwd=ETD;";
            dbConnection = new OleDbConnection(ChaineBd);
            dbConnection.Open();
            #endregion
        }

        // vérifie que tous les champs sont corrects (champ non vide, longueur adéquate ect...)

        private bool conditionCreation()
        {
            string mes_erreur = null;
            bool err = false;

            if (textLogin.Text.Length < 1 || textPass.Text.Length < 1 || textName.Text.Length < 1 || textFirstName.Text.Length < 1)
            {
                mes_erreur += "Erreur : Tous les champs doivent contenir au moins 1 caractère. \n \n";
                err = true;
            }
            if (textPass.Text != textPassConfirm.Text && textPass.Text.Length > 0) //Verification des mots de passe
            {
                mes_erreur += "Erreur : Les deux mots de passe sont différents.\n \n";
                err = true;
            }
            if(textLogin.Text.Length > 10)
            {
                mes_erreur += "Erreur : Le Login doit contenir moins de 10 caractères.\n \n";
                err = true;
            }
            if (textPass.Text.Length > 10)
            {
                mes_erreur += "Erreur : Le Mot de Passe doit contenir moins de 10 caractères..\n \n";
                err = true;
            }
            if (textName.Text.Length > 50)
            {
                mes_erreur += "Erreur : Le Nom doit contenir moins de 50 caractères.\n \n";
                err = true;
            }
            if (textFirstName.Text.Length > 20)
            {
                mes_erreur += "Erreur : Le Prénom doit contenir moins de 20 caractères.\n \n";
                err = true;
            }

            if (!err)
                return true;

            else
            {
                MessageBox.Show(mes_erreur);
                return false;
            }
        }

       
        //Verifie que l'abonné n'existe pas déjà (login, ou COmbinaison "Nom/Prénom")
        private bool verifAbonne()
        {
            connexion();

            string sql = "use Musique "
                        + "SELECT Nom_Abonné, Prénom_Abonné, Login FROM Abonné ";

            bool valid = true;
            string erreurs = null;
                        
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            while (reader.Read() && valid)
            {
                string name = reader.GetValue(0).ToString();
                string firstName = reader.GetValue(1).ToString();
                string login = reader.GetValue(2).ToString();

                if (login == textLogin.Text)
                {
                    valid = false;
                    erreurs +=  "Erreur : login déjà utilisé. \n";
                }
                else if(name == textName.Text && firstName == textFirstName.Text)     
                {
                    valid = false;    
                    erreurs +=  "Erreur : Combinaison \"Nom / Prénom\"  déjà utilisé.";
                }
            }
            reader.Close();
            dbConnection.Close();

            if (valid)
                return true;

            else
            {
                MessageBox.Show(erreurs);
                return false;
            }
        }

        //Ajoute un abonné dans la table
        private void creationAbonne()
        {
            int newCodeAbonne = genererCodeAbonne();
            #region Accès et lecture de la base
            string sql = "use Musique "
                       + "Insert into Abonné (Code_Abonné, Nom_Abonné, Prénom_Abonné, Abonné.Login, Abonné.Password) "
                       + "VALUES (" + newCodeAbonne + ", '" + textName.Text + "', '" + textFirstName.Text + "', '" + textLogin.Text + "', '" + textPass.Text + "')";
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            reader.Read();
            reader.Close();
            #endregion
        }

        //Ferme la fenetre courante
        private void Cancel_Click1(object sender, EventArgs e)
        {
            Close();            
        }

        //Validation et tests pour la création de l'abonné
        private void Confirm_ButtonClick(object sender, EventArgs e)
        {
            if (conditionCreation() && verifAbonne())
            {
                connexion();
                creationAbonne();
                MessageBox.Show("Nouvel abonné(e) créé(e).");
                dbConnection.Close();
                Close();
            }
        }

        //Genere un code abonné n'existant pas (suite au problème de la base données)
        private int genererCodeAbonne()
        {
            #region Accès et lecture de la base
            string sql = "use Musique "
                        + "select DISTINCT Code_Abonné "
                        + "from Abonné";
            OleDbCommand cmd = new OleDbCommand(sql, dbConnection);
            OleDbDataReader reader = cmd.ExecuteReader();
            int newCodeAbonne= 0;
            while (reader.Read())
            {
                if (int.Parse(reader.GetValue(0).ToString()) > newCodeAbonne)
                    newCodeAbonne = int.Parse(reader.GetValue(0).ToString());
            }
            newCodeAbonne++;
            reader.Close();
            return newCodeAbonne;
            #endregion
        }

        //L'ensemble des fonctions suivantes permet de valider en appuyant sur "Entrée" à tout moment
        private void textName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm_ButtonClick(sender, e);
            }
        }

        private void textFirstName_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm_ButtonClick(sender, e);
            }
        }

        private void textLogin_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm_ButtonClick(sender, e);
            }
        }

        private void textPass_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm_ButtonClick(sender, e);
            }
        }

        private void textPassConfirm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                Confirm_ButtonClick(sender, e);
            }
        }        
    }
}
